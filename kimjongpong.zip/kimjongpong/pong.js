//konstruerer canvaset som en variabel
// er en betingelse til canvaset
const canvas = document.getElementById("pong");
const ctx = canvas.getContext('2d');

let tapLyd = new Audio();
let seierLyd = new Audio();

seierLyd.src = "lyd/usSang.mp3";
tapLyd.src = "lyd/lydTap.mp3";


//Her lager jeg variabelen og funksjonene som definerer lett og vanskelig, nemlig hoyde, denne variabelen blir brukt til kimsracket info.
let hoyde = 0;
function lett(){
    hoyde = 60;
}
function vanskelig(){
    hoyde = 101;
}

// tengRekt er funsksjonen som blir brukt for å oppgi "oppskriften på et rektangel", dette retkengelet er "racketene til mskinen og spilleren
            function tegnRekt(x, y, w, h, farge){
                ctx.fillStyle = farge;
                ctx.fillRect(x, y, w, h);
            }

tegnRekt(0, 0, canvas.width, canvas.height, "#000");
//funksjonen som blir utløst når man trykker på start i blir også definert, denne brukes for å ikke kunne kjøre spillet flere ganger samtidig
i=0;
function start(){
        
    if (i===0){
        if (hoyde===0){
            alert("Du må velge vanskelighetsgrad!");
        }   else {
            
                /*Denne linjen skjuler play knappen når spillet starter, slik at det ikke ligger i veien når man spiller*/
                document.getElementById("start").style.visibility ="hidden";
            
                // Objekt med informasjon om raketten
                const rakett = {
                x : canvas.width/2,
                y : canvas.height/2,
                radius : 4,
                hastighetX : 5,
                hastighetY : 5,
                speed : 5,
                farge : "WHITE"
            }

            // objekt med informasjon om trumps racket
            const trump = {
                x : 0, // left side of canvas
                y : (canvas.height - 100)/2, // -100 the height of paddle
                width : 10,
                height : 100,
                score : 0,
                farge : "Cyan"
            }

            // objekt med informasjon om kims racket
            const kim = {
            x : canvas.width - 10, // - width of paddle
            y : (canvas.height - hoyde)/2, // -100 the height of paddle
            width : 10,
            height : hoyde, //Her er en variabel, dette er for at man skal kunne velge vanskelighetsgrad, som egt bare er høyden på "Racketen"
            score : 0,
            farge : "RED"
            }

            


            // denne "mousemove" lytter etter hvor musepekeren er, dette for å kunne oppgi data som faktisk styrer trumps "racket"
            canvas.addEventListener("mousemove", musPos);

            function musPos(evt){
                let rekt = canvas.getBoundingClientRect();
            // Her trump man da altså y kordinatet til musen "clientY" altså opp og ned til å bestemme racketens y posisjon
                trump.y = evt.clientY - rekt.top - trump.height/2;
            }

            // Når spilleren eller kim skårer nullstilles raketten og dette er da den nullstilte plasseringen og hastigheten
            function nullstillRakett(){
                rakett.x = canvas.width/2;
                rakett.y = canvas.height/2;
                rakett.hastighetX = 5;
                rakett.hastighetY = 5;
                rakett.speed = 5;
            }



            // dette er malen på hvordan tekst skal tegnes inn, ("Innholdet, x og y koordinat)
            function tegnTekst(text,x,y){
                ctx.fillStyle = "BLACK";
                ctx.font = "75px fantasy";
                ctx.fillText(text, x, y);
            }


            /* denne kommer me informasjon om når raketten treffer, noe som blir brukt senere i koden i oppdater() under if (collison)*/
            function kollisjon(b,p){
                p.top = p.y;
                p.bottom = p.y + p.height;
                p.left = p.x;
                p.right = p.x + p.width;

                b.top = b.y - b.radius;
                b.bottom = b.y + b.radius;
                b.left = b.x - b.radius;
                b.right = b.x + b.radius;

                return p.left < b.right && p.top < b.bottom && p.right > b.left && p.bottom > b.top;
            }

            /* Denne opdater funksjonen er der alle veridene fra objektene blir tatt i bruk for å få et fungerende spill. her gjøres alle utregninger, betingelser blir satt og denne kjører 50 * isekundet, noe som blir definert i bunn av scriptet, dette for at spillet skal oppfattes som "smooth" */
            function oppdater(){

                    // I denne if betingelsen sjekker vi om ballen er ute og hvor den er ute for ¨å utdele poeng til kim eller spilleren. i denne første betingelsen sjekker vi om rakettens sin posisjon er mindre enn x, altså gått ut på venstre side av canvasset, isåfall skal kim få poeng og raketten nullstilles
                    if( rakett.x - rakett.radius < 0 ){
                        kim.score++;
                        nullstillRakett();
                    //Motsatt her, dersom raketten sin x posisjon er større enn canvasets bredde vil spillerne få poeng og raketten nullstilles
                    }else if( rakett.x + rakett.radius > canvas.width){
                        trump.score++;
                        nullstillRakett();
                    }

                    // ballens hastighet i diagonale rettningen legges til objektet
                    rakett.x += rakett.hastighetX;
                    rakett.y += rakett.hastighetY;

                    /* Dette her er "AI-et" som styrer kims racket, den tar for seg rakketten sin posisjon på y aksen - (kims egen racket på y aksen + halvparten av kims høyde (Som varierer utifra vanskelighetsgrad) og ganger dette medd 0,1 slike at den henger "Litt" bakåp, som gjør det fysisk mulig å slå den  */
                    kim.y += ((rakett.y - (kim.y + kim.height/2)))*0.1;

                    /* rakett hastighet y er den diagonale hastigheten til raketten, her definerer vi denne hastigheten dersom den treffer toppen till bunnen av canvaset. derfor rakett.hastighetY = negative verdien av seg selv, slik at den vil få en "sprett" funksjon og sprette av gårde i motsatt rettning av når den traff. */
                    if(rakett.y - rakett.radius < 0 || rakett.y + rakett.radius > canvas.height){
                        rakett.hastighetY = -rakett.hastighetY;
                    }

                    /* Her sjekker vi om raketten treffer enten treffer trump racket eller kims, dette ved å sjekke om raketten befinner seg på venstre eller høyre side av canvaset ( om rakett.x er mindre ller større enn canvas.width/2.)*/
                    let spiller = (rakett.x + rakett.radius < canvas.width/2) ? trump : kim;

                    /* Dersom ballen skulle treffe en racket, noe som har fått opgitt tidligere i dokumentet i function kollisjon()*/
                    if(kollisjon(rakett,spiller)){

                        /* Her sjekkes hvor på racketen raketten traff, om det var øverst nederst eller midtpå, dette avgjør hvilken rettning ballen vil reflektere tilbake */
                        let collidePoint = (rakett.y - (spiller.y + spiller.height/2));
                        collidePoint = collidePoint / (spiller.height/2);
                        console.log(collidePoint);
                        // Når  raketten treffer toppen eller bunnen av racketen øsnker vi at den skal få en 45 graders vinkel på rettningen sin, derfor lager man angleRad 
                        let vinkelRad = (Math.PI/4) * collidePoint;

                        /* rettningen på x og y aksen endres her med variabelen rettning * farten * sinus eller cosinus avhengig av treffpunktet på racketen */
                        let rettning = (rakett.x + rakett.radius < canvas.width/2) ? 1 : -1;
                        rakett.hastighetX = rettning * rakett.speed * Math.cos(vinkelRad);
                        rakett.hastighetY = rakett.speed * Math.sin(vinkelRad);

                        /* Denne øker hastigheten på raketten med 1 dersom den treffer racketen*/
                        rakett.speed += 1;
                    }
            }

            // tegnOm funksjonen er den som gjør all tegningen i canvaset, altså tenger raketten ved sin nye posisjon, racketen i dens nye posisjon og brettet. alt dette gjøre 50 ganger i sekundet
            function tegnOm(){

                

                var imgTo = document.getElementById("trumpKim");
                    ctx.drawImage(imgTo, 0,0,600,450);

                /* Tegner trumps poengscore til venstre "width /4 "*/
                tegnTekst(trump.score,canvas.width/4,canvas.height/5);

                /*tegner kims poengscore til høyre "3*width/4"*/
                tegnTekst(kim.score,3*canvas.width/4,canvas.height/5);



                /* tegner trumps og kims "racket"*/
                tegnRekt(trump.x, trump.y, trump.width, trump.height, trump.farge);
                tegnRekt(kim.x, kim.y, kim.width, kim.height, kim.farge);


                /*Tegner raketten*/
                var img = document.getElementById("nuke");
                    ctx.drawImage(img,rakett.x-20,rakett.y-10,50,30);


            }
            /*Her starter funksjonen spill som er en masse if else betingelser som styrer reglene for spillet og deremed dets hendelser*/
            function spill(){
                /*Her f.eks bestemmes summen man skal spille til og hva som skjer når kim eller spilleren når denne summen*/
                if (kim.score ===1 || trump.score ===1){
                    /*sånn som her, hvis kim når poengsummen skal "tap" og "seierKim" kjøre med lyd og skrift*/
                    if (kim.score === 1){

                        document.getElementById("tap").style.visibility ="visible";
                        tapLyd.play();
                        let svarE = document.getElementById("svar");
                        svarE.innerHTML="Du tapte :(";

                        /*eller som her, hvis spilleren når poengsummen skal "seier" og "seierTrump" kjøre med lyd og skrift*/
                    } else{
                        document.getElementById("seier").style.visibility ="visible";
                        let svarE = document.getElementById("svar");
                        svarE.innerHTML="Du vant! :)";
                        seierLyd.play();
                    }
                } else {
                    /*Her kjører den dersom ingen har nådd poengsummen, ltså oppdater kjører igjen og tegnOm nullstiller brettet*/
                    oppdater(); 
                    tegnOm();
                }


            }
            /* variabel for fps, denne legges til i setInterval funksjonen loop unnder, dette gjør at spillet oppdateres 50 ganger per sekund(1000/50)*/
            let framePerSecond = 50;
            let loop = setInterval(spill,1000/framePerSecond);
            i++;
        }
    
    }

    
        
}
//koden til menyen i venstre hjørne
function openMeny(){
    document.getElementById("meny").style.width="20.5%";
}
function lukkMeny(){
    document.getElementById("meny").style.width="0%";
}
